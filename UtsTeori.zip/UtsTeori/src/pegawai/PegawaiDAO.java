/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pegawai;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import database.DAO;
import database.Koneksi;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import sepatu.Sepatu;
import sepatu.SepatuDAO;

/**
 *
 * @author T.o.P
 */
public class PegawaiDAO implements DAO {
      Dao<Pegawai, Integer> dao;

    public PegawaiDAO() {

        try {
            dao = DaoManager.createDao(Koneksi.cs(), Pegawai.class);
        } catch (SQLException ex) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void insert(Object o) {
        try {
            dao.create((Pegawai) o);
            JOptionPane.showMessageDialog(null, "Tambah data berhasil");
        } catch (SQLException ex) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object o) {
        try {
            dao.update((Pegawai) o);
            JOptionPane.showMessageDialog(null, "Ubah data berhasil");
        } catch (SQLException ex) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void delete(int id) {
        try {
            dao.deleteById((id));
            JOptionPane.showMessageDialog(null, "hapus data berhasil");
        } catch (SQLException ex) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public DefaultTableModel selectAll() {
        //deklarasi tabel model
        DefaultTableModel dtm;
        //nama kolom
        String[] colHeader = {"Id", "Nama", "username","password"};
        //table default
        dtm = new DefaultTableModel(null, colHeader);
        try {
            List<Pegawai> pgw = dao.queryForAll();
            for (Pegawai p : pgw) {
                Object[] isi = new Object[6];
                isi[0] = p.getId();
                isi[1] = p.getNama();
                isi[2] = p.getUsername();
                isi[3] = p.getPassword();
                
                dtm.addRow(isi);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SepatuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return dtm;
    }

    @Override
    public DefaultTableModel search(String key) {
        //deklarasi tabel model
        DefaultTableModel dtm;
        //nama kolom
        String[] colHeader = {"Id", "Nama", "username","password"};
        //table default
        dtm = new DefaultTableModel(null, colHeader);
        try {
            List<Pegawai> pegawai = dao.queryBuilder().where().like("nama", "%" + key + "%").query();
            for (Pegawai p : pegawai) {
                Object[] isi = new Object[6];
                isi[0] = p.getId();
                isi[1] = p.getNama();
                isi[2] = p.getUsername();
                isi[3] = p.getPassword();
              
                
                dtm.addRow(isi);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SepatuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return dtm;
    }
}
