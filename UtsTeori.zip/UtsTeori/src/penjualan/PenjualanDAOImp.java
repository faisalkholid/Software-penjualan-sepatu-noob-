/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualan;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import database.Koneksi;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static penjualan.PenjualanForm.index;
import penjualan_item.PenjualanItem;

/**
 *
 * @author T.o.P
 */
public class PenjualanDAOImp implements PenjualanDAO{
      private Dao<Penjualan, Integer> dao;
    private Dao<PenjualanItem, Integer> daoitm;

    public PenjualanDAOImp() {
        try {
            dao = DaoManager.createDao(Koneksi.cs(), Penjualan.class);
            daoitm = DaoManager.createDao(Koneksi.cs(), PenjualanItem.class);
        } catch (SQLException ex) {
            Logger.getLogger(PenjualanDAOImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public DefaultTableModel selectAll() {
        DefaultTableModel dtm;
        String[] title = {"ID", "Tanggal ", "Total", "Pegawai"};
        dtm = new DefaultTableModel(null, title);
        try {
            List<Penjualan> Penjualan = dao.queryForAll();
            for (Penjualan p : Penjualan) {
                Object[] o = new Object[4];
                o[0] = p.getId();
                o[1] = p.getTanggal();
                o[2] = p.getTotal();
                o[3] = p.getPegawai().getNama();

                dtm.addRow(o);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PenjualanDAOImp.class.getName()).log(Level.SEVERE, null, ex);
        }
        //kembalikan hasil dtm
        return dtm;

    }

    @Override
    public DefaultTableModel cari(String key) {
        DefaultTableModel dtm;
        String[] title = {"ID", "Tanggal", "total", "Pegawai"};
        dtm = new DefaultTableModel(null, title);
        try {
            List<Penjualan> Penjualan = dao.queryBuilder().where().like("Tanggal", "%" + key +"%").query();
            for (Penjualan p : Penjualan) {
                Object[] o = new Object[4];
                o[0] = p.getId();
                o[1] = p.getTanggal();
                o[2] = p.getTotal();
                o[3] = p.getPegawai().getNama();
                

                dtm.addRow(o);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PenjualanDAOImp.class.getName()).log(Level.SEVERE, null, ex);
        }
        //kembalikan hasil dtm
        return dtm;
    }

    @Override
    public DefaultTableModel detail(int id) {
        DefaultTableModel dtm;
        String judul[] = {"ID", "Nama Barang", "Harga Jual", "Qty", "Sub Total"};
        dtm = new DefaultTableModel(null, judul);
        try {
            List<PenjualanItem> penjualanItem = daoitm.queryForEq("penjualan_id", id);
            for (PenjualanItem p : penjualanItem) {
                
                Object o[] = new Object[5];
                o[0] = p.getId();
                o[1] = p.getSepatu().getNama();
                o[2] = p.getSepatu().getHarga_jual();
                o[3] = p.getQty();
                o[4] = p.getSubtotal();
                dtm.addRow(o);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PenjualanDAOImp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dtm;
    }
   
}