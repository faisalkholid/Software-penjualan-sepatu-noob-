/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualan;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import pegawai.Pegawai;

/**
 *
 * @author T.o.P
 */
@DatabaseTable(tableName = "penjualan")
public class Penjualan {
    @DatabaseField(generatedId = true)
    private int id;
    @DatabaseField
    private String tanggal;
    @DatabaseField
    private double total;
    
    @DatabaseField(foreign = true, foreignAutoRefresh = true)
    private Pegawai pegawai;

    public Pegawai getPegawai() {
        return pegawai;
    }

    public void setPegawai(Pegawai pegawai) {
        this.pegawai = pegawai;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
