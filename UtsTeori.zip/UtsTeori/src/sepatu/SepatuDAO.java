/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sepatu;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import database.Koneksi;
import database.DAO;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author T.o.P
 */
public class SepatuDAO implements DAO{

    Dao<Sepatu, Integer> dao;

    public SepatuDAO() {

        try {
            dao = DaoManager.createDao(Koneksi.cs(), Sepatu.class);
        } catch (SQLException ex) {
            Logger.getLogger(SepatuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void insert(Object o) {
        try {
            dao.create((Sepatu) o);
            JOptionPane.showMessageDialog(null, "Tambah data berhasil");
        } catch (SQLException ex) {
            Logger.getLogger(SepatuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object o) {
        try {
            dao.update((Sepatu) o);
            JOptionPane.showMessageDialog(null, "Ubah data berhasil");
        } catch (SQLException ex) {
            Logger.getLogger(SepatuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void delete(int id) {
        try {
            dao.deleteById((id));
            JOptionPane.showMessageDialog(null, "hapus data berhasil");
        } catch (SQLException ex) {
            Logger.getLogger(SepatuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public DefaultTableModel selectAll() {
        //deklarasi tabel model
        DefaultTableModel dtm;
        //nama kolom
        String[] colHeader = {"Id", "Nama", "Produsen","Harga Jual","Ukuran","Stok"};
        //table default
        dtm = new DefaultTableModel(null, colHeader);
        try {
            List<Sepatu> sepatu = dao.queryForAll();
            for (Sepatu s : sepatu) {
                Object[] isi = new Object[6];
                isi[0] = s.getId();
                isi[1] = s.getNama();
                isi[2] = s.getProdusen();
                isi[3] = s.getHarga_jual();
                isi[4] = s.getUkuran();
                isi[5] = s.getStok();
                
                dtm.addRow(isi);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SepatuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return dtm;
    }

    @Override
    public DefaultTableModel search(String key) {
        //deklarasi tabel model
        DefaultTableModel dtm;
        //nama kolom
        String[] colHeader = {"Id", "Nama", "Harga Jual","Ukuran","Produsen","Stok"};
        //table default
        dtm = new DefaultTableModel(null, colHeader);
        try {
            List<Sepatu> sepatu = dao.queryBuilder().where().like("nama", "%" + key + "%").query();
            for (Sepatu s : sepatu) {
                Object[] isi = new Object[6];
                isi[0] = s.getId();
                isi[1] = s.getNama();
                isi[2] = s.getHarga_jual();
                isi[3] = s.getUkuran();
                isi[4] = s.getProdusen();
                isi[5] = s.getStok();
                
                dtm.addRow(isi);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SepatuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return dtm;
    }

}
