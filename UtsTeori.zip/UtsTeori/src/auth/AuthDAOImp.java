/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package auth;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import database.Koneksi;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import pegawai.Pegawai;

/**
 *
 * @author T.o.P
 */
public class AuthDAOImp implements AuthDAO {

    private Dao<Pegawai, Integer> dao;

    public AuthDAOImp() {
        try {
            //hubungkan cs dengan dao
            dao = DaoManager.createDao(Koneksi.cs(), Pegawai.class);
        } catch (SQLException ex) {
            Logger.getLogger(AuthDAOImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void login(String username, String password) {
        try {
            Pegawai pegawai = dao.queryBuilder().where()
                    .eq("username", username)
                    .and()
                    .eq("password", password)
                    .queryForFirst();
            if(pegawai != null){
                Auth.ID = pegawai.getId();
                Auth.NAMA = pegawai.getNama();
                Auth.AUTH = true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }

    @Override
    public void logout() {
        Auth.ID = 0;
        Auth.NAMA = null;
        Auth.AUTH = false;
    }

}
