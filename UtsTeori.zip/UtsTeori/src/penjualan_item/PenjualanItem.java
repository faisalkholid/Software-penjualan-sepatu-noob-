/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualan_item;

import sepatu.Sepatu;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import pegawai.Pegawai;
import penjualan.Penjualan;

/**
 *
 * @author T.o.P
 */
@DatabaseTable(tableName = "penjualan_item")
public class PenjualanItem {

    @DatabaseField(generatedId = true)
    private int id;
    @DatabaseField
    private int qty;
    @DatabaseField
    private double subtotal;

    @DatabaseField(foreign = true, foreignAutoRefresh = true)
    private Penjualan penjualan;
    @DatabaseField(foreign = true, foreignAutoRefresh = true)
    private Sepatu sepatu;

  
   

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public Penjualan getPenjualan() {
        return penjualan;
    }

    public void setPenjualan(Penjualan penjualan) {
        this.penjualan = penjualan;
    }

    public Sepatu getSepatu() {
        return sepatu;
    }

    public void setSepatu(Sepatu sepatu) {
        this.sepatu = sepatu;
    }
    

}
