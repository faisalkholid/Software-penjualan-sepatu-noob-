/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualan_item;

import sepatu.Sepatu;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import database.Koneksi;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import penjualan.Penjualan;

/**
 *
 * @author T.o.P
 */
public class PenjualanItemDAOimp implements PenjualanItemDAO {
    private Dao<Sepatu, Integer> daoSepatu;
    private Dao<Penjualan, Integer> daoPenjualan;
    private Dao<PenjualanItem, Integer> daoPenjualanItems;
//  LIST ITEM SEMENTARA
    private List<PenjualanItem> items = new ArrayList<>();

    public PenjualanItemDAOimp() {

        try {
            daoSepatu = DaoManager.createDao(Koneksi.cs(), Sepatu.class);
            daoPenjualan = DaoManager.createDao(Koneksi.cs(), Penjualan.class);
            daoPenjualanItems = DaoManager.createDao(Koneksi.cs(), PenjualanItem.class);
        } catch (SQLException ex) {
            Logger.getLogger(PenjualanItemDAOimp.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public List<Sepatu> loadSepatu() {
        List<Sepatu> sepatu = null;
        try {
            sepatu = daoSepatu.queryForAll();
        } catch (SQLException ex) {
            Logger.getLogger(PenjualanItemDAOimp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sepatu;
    }

    @Override
    public void addItem(PenjualanItem item) {
        items.add(item);
    }

    @Override
    public void deleteItem(int index) {
        items.remove(index);
    }

    @Override
    public double refreshtotal() {
        double total = 0;
        for (PenjualanItem item : items) {
            total += item.getSubtotal();
        }
        return total;
    }

    @Override
    public DefaultTableModel viewItem() {
        DefaultTableModel dtm;
        String[] title = {"ID", "Nama", "Harga Jual", "Qty", "Sub Total"};
        dtm = new DefaultTableModel(null, title);
        for (PenjualanItem item : items) {
            Object[] o = new Object[5];
            o[0] = item.getSepatu().getId();
            o[1] = item.getSepatu().getNama();
            o[2] = item.getSepatu().getHarga_jual();
            o[3] = item.getQty();
            o[4] = item.getSubtotal();
            dtm.addRow(o);
        }

        //kembalikan hasil dtm
        return dtm;

    }

    @Override
    public void insertPenjualan(Penjualan p) {
        try {
            p.setTotal(refreshtotal());
            daoPenjualan.create(p);

            for (PenjualanItem i : items) {
                PenjualanItem penjualanItem = new PenjualanItem();
                //set penjualan
                penjualanItem.setPenjualan(p);
                penjualanItem.setQty(i.getQty());
                penjualanItem.setSubtotal(i.getSubtotal());

                //setbarang
                penjualanItem.setSepatu(i.getSepatu());
                daoPenjualanItems.create(penjualanItem);
                
            }
            JOptionPane.showMessageDialog(null, "Transaksi penjualan telah tersimpan");
        } catch (SQLException ex) {
            Logger.getLogger(PenjualanItemDAOimp.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void reset() {
        items.removeAll(items);
    }

}
