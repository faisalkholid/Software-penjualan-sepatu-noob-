-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 09 Mei 2017 pada 05.27
-- Versi Server: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `p.sepatu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`id`, `nama`, `username`, `password`) VALUES
(1, 'faisal', 'admin', 'admin'),
(2, 'fatih', 'admin02', 'admin02');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `total` double DEFAULT NULL,
  `pegawai_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`id`, `tanggal`, `total`, `pegawai_id`) VALUES
(1, '2017-05-02', 3000, 1),
(2, '2017-05-02', 2000, 1),
(3, '2017-05-02', 5000, 1),
(4, '2017-05-03', 5000, 1),
(5, '2017-05-03', 18000, 2),
(6, '2017-05-03', 1000, 2),
(7, '2017-05-03', 20000000, 1),
(8, '2017-05-03', 2000, 1),
(9, '2017-05-04', 600000, 1),
(11, '2017-05-04', 1000, 1),
(12, '2017-05-05', 1000, 1),
(13, '2017-05-08', 301000, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan_item`
--

CREATE TABLE `penjualan_item` (
  `id` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `penjualan_id` int(11) NOT NULL,
  `sepatu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `penjualan_item`
--

INSERT INTO `penjualan_item` (`id`, `qty`, `subtotal`, `penjualan_id`, `sepatu_id`) VALUES
(1, 3, 3000, 1, 1),
(2, 2, 2000, 2, 1),
(3, 1, 1000, 3, 1),
(4, 2, 4000, 3, 2),
(5, 1, 1000, 4, 1),
(6, 2, 4000, 4, 2),
(7, 1, 1000, 5, 1),
(8, 3, 3000, 5, 1),
(9, 0, 0, 5, 2),
(10, 1, 2000, 5, 2),
(11, 1, 2000, 5, 2),
(12, 5, 10000, 5, 2),
(13, 1, 1000, 6, 1),
(15, 2, 2000, 8, 1),
(16, 1, 200000, 9, 2),
(18, 1, 1000, 11, 1),
(19, 1, 1000, 12, 1),
(20, 1, 1000, 13, 1),
(21, 1, 300000, 13, 4);

--
-- Trigger `penjualan_item`
--
DELIMITER $$
CREATE TRIGGER `penjualan_item_AFTER_INSERT` AFTER INSERT ON `penjualan_item` FOR EACH ROW BEGIN
	update sepatu set stok = stok - new.qty 
	where id = new.sepatu_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `sepatu`
--

CREATE TABLE `sepatu` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `harga_jual` double DEFAULT NULL,
  `ukuran` int(11) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `produsen` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `sepatu`
--

INSERT INTO `sepatu` (`id`, `nama`, `harga_jual`, `ukuran`, `stok`, `produsen`) VALUES
(1, 'adizero', 1000, 42, 5, 'nike'),
(2, 'nike monster', 200000, 25, 5, 'nike'),
(4, 'specs sport', 300000, 45, 7, 'specs'),
(5, 'airwalk z', 400000, 45, 5, 'airwalk');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_penjualan_pegawai1_idx` (`pegawai_id`);

--
-- Indexes for table `penjualan_item`
--
ALTER TABLE `penjualan_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_penjualan_item_penjualan1_idx` (`penjualan_id`),
  ADD KEY `fk_penjualan_item_sepatu1_idx` (`sepatu_id`);

--
-- Indexes for table `sepatu`
--
ALTER TABLE `sepatu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `penjualan_item`
--
ALTER TABLE `penjualan_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `sepatu`
--
ALTER TABLE `sepatu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `fk_penjualan_pegawai1` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `penjualan_item`
--
ALTER TABLE `penjualan_item`
  ADD CONSTRAINT `fk_penjualan_item_penjualan1` FOREIGN KEY (`penjualan_id`) REFERENCES `penjualan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_penjualan_item_sepatu1` FOREIGN KEY (`sepatu_id`) REFERENCES `sepatu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
